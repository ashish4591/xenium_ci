<?php

echo "Test page";
?>